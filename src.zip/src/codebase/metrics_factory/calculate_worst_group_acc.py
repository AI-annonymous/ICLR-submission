from metrics_factory import auroc


def calculate_worst_group_acc_waterbirds(
        df, pred_col, attribute_col="attribute_bg_predict", filter_waterbirds=True, filter_landbirds=True):
    df[pred_col] = (df[pred_col] >= 0.5).astype(int)
    # print(f"\ndf: {df.shape}")
    # print(df.head())
    acc_waterbirds_land = 0
    acc_landbirds_water = 0
    if attribute_col == "attribute_bg_predict":
        concept_1 = "water"
        concept_2 = "land"
    else:
        concept_1 = f"w_{attribute_col}"
        concept_2 = f"w/o_{attribute_col}"

    if filter_waterbirds:
        print("#############" * 10)
        print("####################################### Waterbirds Stats #######################################")
        waterbirds_df = df[df["out_put_GT"] == 1]
        waterbirds_df_water_bg = waterbirds_df[waterbirds_df[attribute_col] == 1]
        waterbirds_df_land_bg = waterbirds_df[waterbirds_df[attribute_col] == 0]
        print(f"GT Shape Waterbirds on {concept_1} bg: {waterbirds_df_water_bg.shape}")
        print(
            f"Pred Shape Waterbirds on {concept_1} bg: {waterbirds_df_water_bg[waterbirds_df_water_bg[pred_col] == 1].shape}"
        )
        acc_waterbirds_water = waterbirds_df_water_bg[waterbirds_df_water_bg[pred_col] == 1].shape[0] / \
                               waterbirds_df_water_bg.shape[0]
        print(f"acc Waterbirds on {concept_1} bg: {acc_waterbirds_water}")

        print(f"GT Shape Waterbirds on {concept_2} bg: {waterbirds_df_land_bg.shape}")
        print(
            f"Pred Shape Waterbirds on {concept_2} bg: {waterbirds_df_land_bg[waterbirds_df_land_bg[pred_col] == 1].shape}"
        )
        acc_waterbirds_land = waterbirds_df_land_bg[waterbirds_df_land_bg[pred_col] == 1].shape[0] / \
                              waterbirds_df_land_bg.shape[0]

        print(f"acc Waterbirds on {concept_2} bg: {acc_waterbirds_land}")
        print("#############" * 10)

    if filter_landbirds:
        print("#############" * 10)
        print("####################################### Landbirds Stats #######################################")
        landbirds_df = df[df["out_put_GT"] == 0]
        landbirds_df_water_bg = landbirds_df[landbirds_df[attribute_col] == 1]
        landbirds_df_land_bg = landbirds_df[landbirds_df[attribute_col] == 0]
        print(f"GT Shape Landbirds on {concept_1} bg: {landbirds_df_water_bg.shape}")
        print(
            f"Pred Shape Landbirds on {concept_1} bg: {landbirds_df_water_bg[landbirds_df_water_bg[pred_col] == 0].shape}"
        )
        acc_landbirds_water = landbirds_df_water_bg[landbirds_df_water_bg[pred_col] == 0].shape[0] / \
                              landbirds_df_water_bg.shape[0]
        print(f"acc Landbirds on {concept_1} bg: {acc_landbirds_water}")

        print(f"GT Shape Landbirds on {concept_2} bg: {landbirds_df_land_bg.shape}")
        print(
            f"Pred Shape Landbirds on {concept_2} bg: {landbirds_df_land_bg[landbirds_df_land_bg[pred_col] == 0].shape}"
        )
        acc_landbirds_land = landbirds_df_land_bg[landbirds_df_land_bg[pred_col] == 0].shape[0] / \
                             landbirds_df_land_bg.shape[0]

        print(f"acc Landbirds on {concept_2} bg: {acc_landbirds_land}")
        print("#############" * 10)

    # df_vertical = pd.concat([waterbirds_df_land_bg, landbirds_df_water_bg], axis=0).reset_index(drop=True)
    # worst = (df_vertical["out_put_GT"].values == df_vertical[pred_col].values).sum() / df_vertical.shape[0]
    # print(f"\n Avg worst group acc: {worst}")

    avg = (df["out_put_GT"].values == df[pred_col].values).sum() / df.shape[0]
    avg_wga = (acc_waterbirds_land + acc_landbirds_water) / 2
    print(f"Avg acc: {avg}")

    if filter_waterbirds and filter_landbirds:
        print(f"Avg worst group acc: {avg_wga}")
        return avg_wga
    elif filter_waterbirds:
        print(f"Avg worst group acc: {acc_waterbirds_land}")
        return acc_waterbirds_land
    elif filter_landbirds:
        print(f"Avg worst group acc: {acc_landbirds_water}")
        return acc_landbirds_water


def calculate_worst_group_acc_metashift(
        df, pred_col, attribute_col="attribute_bg_predict", filter_cats=True, filter_dogs=True):
    df[pred_col] = (df[pred_col] >= 0.5).astype(int)
    print(f"df: {df.shape}")
    acc_cat_outdoor = 0
    acc_dogs_indoor = 0
    if attribute_col == "attribute_bg_predict":
        concept_1 = "indoor"
        concept_2 = "outdoor"
    else:
        concept_1 = f"w_{attribute_col}"
        concept_2 = f"w/o_{attribute_col}"

    if filter_cats:
        print("#############" * 10)
        print("####################################### Cat Stats #######################################")
        cat_df = df[df["out_put_GT"] == 1]
        cat_indoor = cat_df[cat_df[attribute_col] == 1]
        cat_outdoor = cat_df[cat_df[attribute_col] == 0]
        print(f"GT Shape cat ({concept_1}) bg: {cat_indoor.shape}")
        print(
            f"Pred Shape cat ({concept_1})r bg: {cat_indoor[cat_indoor[pred_col] == 1].shape}"
        )
        acc_cat_indoor = cat_indoor[cat_indoor[pred_col] == 1].shape[0] / cat_indoor.shape[0]
        print(f"acc cat ({concept_1}) bg: {acc_cat_indoor}")

        print(f"GT Shape cat ({concept_2}) bg: {cat_outdoor.shape}")
        print(
            f"Pred Shape cat ({concept_2}) bg: {cat_outdoor[cat_outdoor[pred_col] == 1].shape}"
        )
        acc_cat_outdoor = cat_outdoor[cat_outdoor[pred_col] == 1].shape[0] / cat_outdoor.shape[0]

        print(f"acc cat ({concept_2}) bg: {acc_cat_outdoor}")
        print("#############" * 10)

    print("\n")
    if filter_dogs:
        print("#############" * 10)
        print("####################################### Dog Stats #######################################")
        dog_df = df[df["out_put_GT"] == 0]
        dogs_indoor = dog_df[dog_df[attribute_col] == 1]
        dogs_outdoor = dog_df[dog_df[attribute_col] == 0]
        print(f"GT Shape dog ({concept_1}) bg: {dogs_indoor.shape}")
        print(
            f"Pred Shape dog ({concept_1}) bg: {dogs_indoor[dogs_indoor[pred_col] == 0].shape}"
        )
        acc_dogs_indoor = dogs_indoor[dogs_indoor[pred_col] == 0].shape[0] / dogs_indoor.shape[0]
        print(f"acc dog ({concept_1}) bg: {acc_dogs_indoor}")

        print(f"GT Shape dog ({concept_2}) bg: {dogs_outdoor.shape}")
        print(
            f"Pred Shape dog ({concept_2}) bg: {dogs_outdoor[dogs_outdoor[pred_col] == 0].shape}"
        )
        acc_dogs_outdoor = dogs_outdoor[dogs_outdoor[pred_col] == 0].shape[0] / \
                           dogs_outdoor.shape[0]

        print(f"acc dog ({concept_2}) bg: {acc_dogs_outdoor}")
        print("#############" * 10)

    avg = (df["out_put_GT"].values == df[pred_col].values).sum() / df.shape[0]
    print(f"Avg acc: {avg}")
    avg_wga = (acc_dogs_indoor + acc_cat_outdoor) / 2
    if filter_cats and filter_dogs:
        print(f"Avg worst group acc: {avg_wga}")
        return avg_wga
    elif filter_cats:
        print(f"Avg worst group acc: {acc_cat_outdoor}")
        return acc_cat_outdoor
    elif filter_dogs:
        print(f"Avg worst group acc: {acc_dogs_indoor}")
        return acc_dogs_indoor


def calculate_worst_group_acc_celebA(df, pred_col, attribute_col="attribute_bg_predict", print_non_blonde=True):
    df[pred_col] = (df[pred_col] >= 0.5).astype(int)
    if attribute_col == "attribute_bg_predict":
        concept_1 = "male"
        concept_2 = "female"
    else:
        concept_1 = f"w_{attribute_col}"
        concept_2 = f"w/o_{attribute_col}"
    print("#############" * 10)
    print("####################################### CelebA Stats #######################################")
    blonde_df = df[df["out_put_GT"] == 1]
    blonde_male_df = blonde_df[blonde_df[attribute_col] == 1]
    blonde_female_df = blonde_df[blonde_df[attribute_col] == 0]
    print(f"GT Shape blonde {concept_1}: {blonde_male_df.shape}")
    print(
        f"Pred Shape blonde {concept_1}: {blonde_male_df[blonde_male_df[pred_col] == 1].shape}"
    )
    acc_blonde_male = blonde_male_df[blonde_male_df[pred_col] == 1].shape[0] / \
                      blonde_male_df.shape[0]
    print(f"acc blonde {concept_1}: {acc_blonde_male}")

    print(f"GT Shape blonde {concept_2}: {blonde_female_df.shape}")
    print(
        f"Pred Shape blonde {concept_2}: {blonde_female_df[blonde_female_df[pred_col] == 1].shape}"
    )
    acc_blonde_female = blonde_female_df[blonde_female_df[pred_col] == 1].shape[0] / \
                        blonde_female_df.shape[0]

    print(f"acc blonde {concept_2}: {acc_blonde_female}")
    print("#############" * 10)

    avg = (df["out_put_GT"].values == df[pred_col].values).sum() / df.shape[0]
    print(f"==============>>> Avg acc: {avg} <<<==============")

    if attribute_col == "attribute_bg_predict":
        print(f"==============>>> Worst acc, blonde-{concept_1}: {acc_blonde_male} <<<==============")
        acc = acc_blonde_male
    else:
        print(f"==============>>> Worst acc, blonde-{concept_2}: {acc_blonde_female} <<<==============")
        acc = acc_blonde_female

    if print_non_blonde:
        non_blonde_df = df[df["out_put_GT"] == 0]
        non_blonde_male_df = non_blonde_df[non_blonde_df[attribute_col] == 1]
        non_blonde_female_df = non_blonde_df[non_blonde_df[attribute_col] == 0]
        print(f"GT Shape non blonde {concept_1}: {non_blonde_male_df.shape}")
        print(
            f"Pred Shape non blonde {concept_1}: {non_blonde_male_df[non_blonde_male_df[pred_col] == 0].shape}"
        )
        acc_non_blonde_male = non_blonde_male_df[non_blonde_male_df[pred_col] == 0].shape[0] / \
                              non_blonde_male_df.shape[0]
        print(f"acc non blonde {concept_1}: {acc_non_blonde_male}")

        print(f"GT Shape non blonde {concept_2}: {non_blonde_female_df.shape}")
        print(
            f"Pred Shape non blonde {concept_2}: {non_blonde_female_df[non_blonde_female_df[pred_col] == 0].shape}"
        )
        acc_non_blonde_female = non_blonde_female_df[non_blonde_female_df[pred_col] == 0].shape[0] / \
                                non_blonde_female_df.shape[0]

        print(f"acc non blonde {concept_2}: {acc_non_blonde_female}")
        print("#############" * 10)
    return acc


def calculate_worst_group_acc_rsna_mammo(df, pred_col, attribute_col="calc"):
    df["out_put_predict_bin"] = (df["out_put_predict"] >= 0.5).astype(int)
    aucroc = auroc(gt=df["out_put_GT"].values, pred=df["out_put_predict"].values)
    print("Overall AUC-ROC for the whole dataset (Initial model): ", aucroc)
    if f"{pred_col}_proba" in df.columns:
        aucroc = auroc(gt=df["out_put_GT"].values, pred=df[f"{pred_col}_proba"].values)
        print("Overall AUC-ROC for the whole dataset (Cur model): ", aucroc)
    print(f"df: {df.shape}")

    if "_bin" not in pred_col:
        pred_col = f"{pred_col}_bin"
    print(f"################################# RSNA Cancer with {attribute_col} #################################")
    cancer_df = df[df["out_put_GT"] == 1]
    cancer_df_w_attr = cancer_df[cancer_df[attribute_col] == 1]
    cancer_df_wo_attr = cancer_df[cancer_df[attribute_col] == 0]
    print(f"[Shape] Cancer GT with {attribute_col}: {cancer_df_w_attr.shape}")
    print(
        f"[Shape] Cancer Pred with {attribute_col}: {cancer_df_w_attr[cancer_df_w_attr[pred_col] == 1].shape}"
    )
    acc_cancer_attr = cancer_df_w_attr[cancer_df_w_attr[pred_col] == 1].shape[0] / cancer_df_w_attr.shape[0]

    print(f"[Shape] Cancer GT without {attribute_col}: {cancer_df_wo_attr.shape}")
    print(
        f"[Shape] Cancer Pred without {attribute_col}: {cancer_df_wo_attr[cancer_df_wo_attr[pred_col] == 1].shape}"
    )
    acc_cancer_wo_attr = cancer_df_wo_attr[cancer_df_wo_attr[pred_col] == 1].shape[0] / cancer_df_wo_attr.shape[0]

    print(f"acc Cancer with {attribute_col}: {acc_cancer_attr}")
    print(f"acc Cancer without {attribute_col}: {acc_cancer_wo_attr}")

    print(f"Mean accuracy: {df[df[pred_col] == df['out_put_GT']].shape[0] / df.shape[0]}")

    return acc_cancer_wo_attr


def calculate_worst_group_acc_nih(df, pred_col, attribute_col):
    df["out_put_predict_bin"] = (df["out_put_predict"] >= 0.5).astype(int)
    aucroc = auroc(gt=df["out_put_GT"].values, pred=df["out_put_predict"].values)
    print("Overall AUC-ROC for the whole dataset (Initial model): ", aucroc)
    if f"{pred_col}_proba" in df.columns:
        aucroc = auroc(gt=df["out_put_GT"].values, pred=df[f"{pred_col}_proba"].values)
        print("Overall AUC-ROC for the whole dataset (Cur model): ", aucroc)
    print(
        f"Mean accuracy ((Initial model)): {df[df['out_put_GT'] == df['out_put_predict_bin']].shape[0] / df.shape[0]}")
    # print(" ")
    # print("\n")

    if "_bin" not in pred_col:
        pred_col = f"{pred_col}_bin"
    print(f"############################ Accuracies NIH Pneumothorax with {attribute_col} #########################")
    df[pred_col] = (df[pred_col] >= 0.5).astype(int)
    print(f"df: {df.shape}")

    pt_df = df[df["out_put_GT"] == 1]
    # pt_df = df
    pt_df_w_attr = pt_df[pt_df[attribute_col] == 1]
    pt_df_wo_attr = pt_df[pt_df[attribute_col] == 0]
    print(f"[Shape] Pneumothorax GT with {attribute_col}: {pt_df_w_attr.shape}")
    print(
        f"[Shape] Pneumothorax Pred with {attribute_col}: {pt_df_w_attr[pt_df_w_attr[pred_col] == 1].shape}"
    )
    acc_pt_attr = pt_df_w_attr[pt_df_w_attr[pred_col] == 1].shape[0] / pt_df_w_attr.shape[0]

    print(f"[Shape] Pneumothorax GT without {attribute_col}: {pt_df_wo_attr.shape}")
    print(
        f"[Shape] Pneumothorax Pred without {attribute_col}: {pt_df_wo_attr[pt_df_wo_attr[pred_col] == 1].shape}"
    )
    acc_pt_wo_attr = pt_df_wo_attr[pt_df_wo_attr[pred_col] == 1].shape[0] / pt_df_wo_attr.shape[0]

    print(f"acc Pneumothorax with {attribute_col}: {acc_pt_attr}")
    print(f"acc Pneumothorax without {attribute_col}: {acc_pt_wo_attr}")

    print(f"Mean accuracy: {df[df[pred_col] == df['out_put_GT']].shape[0] / df.shape[0]}")

    return acc_pt_wo_attr


def calculate_worst_group_acc_chexpert_no_findings(df, pred_col, attribute_col="attribute"):
    df[pred_col] = (df[pred_col] >= 0.5).astype(int)
    print(f"df: {df.shape}")
    print(df.head())

    print("#############" * 10)
    print("####################################### Waterbirds Stats #######################################")
    no_findings = df[df["out_put_GT"] == 1]
    no_findings_male_white = no_findings[no_findings[attribute_col] == 0]
    no_findings_male_black = no_findings[no_findings[attribute_col] == 1]
    no_findings_male_other = no_findings[no_findings[attribute_col] == 2]
    no_findings_female_white = no_findings[no_findings[attribute_col] == 3]
    no_findings_female_black = no_findings[no_findings[attribute_col] == 4]
    no_findings_female_other = no_findings[no_findings[attribute_col] == 5]

    print(f"GT Shape no_findings_male_white: {no_findings_male_white.shape}")
    print(
        f"Pred Shape no_findings_male_white: {no_findings_male_white[no_findings_male_white[pred_col] == 1].shape}"
    )
    acc_no_findings_male_white = no_findings_male_white[no_findings_male_white[pred_col] == 1].shape[0] / \
                                 no_findings_male_white.shape[0]
    print(f"acc acc_no_findings_male_white: {acc_no_findings_male_white}")

    print("============================================================")
    print(f"GT Shape no_findings_male_black: {no_findings_male_black.shape}")
    print(
        f"Pred Shape no_findings_male_black: {no_findings_male_black[no_findings_male_black[pred_col] == 1].shape}"
    )
    acc_no_findings_male_black = no_findings_male_black[no_findings_male_black[pred_col] == 1].shape[0] / \
                                 no_findings_male_black.shape[0]
    print(f"acc no_findings_male_black: {acc_no_findings_male_black}")

    print("============================================================")
    print(f"GT Shape no_findings_male_other: {no_findings_male_other.shape}")
    print(
        f"Pred Shape no_findings_male_other: {no_findings_male_other[no_findings_male_other[pred_col] == 1].shape}"
    )
    acc_no_findings_male_other = no_findings_male_other[no_findings_male_other[pred_col] == 1].shape[0] / \
                                 no_findings_male_other.shape[0]
    print(f"acc no_findings_male_other: {acc_no_findings_male_other}")
