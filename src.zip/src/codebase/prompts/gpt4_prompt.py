def create_NIH_prompts(content):
    prompt_dict = """
    prompt_dict = 
    {
        H1_<attribute>: [List of prompts],
        H2_<attribute>: [List of prompts]
        ...
    }

    """

    hyp_dict = """
        hypothesis_dict = {
        "H1": "The classifier is making mistake  as it is biased toward <attribute>",
        "H2": "The classifier is making mistake as it is biased toward <attribute>",
        "H3": "The classifier is making mistake as it is biased toward <attribute>",
        ...
        }
    """

    prompt = f"""
    Context: Pneumothorax classification from chest-x-rays using a deep neural network
    Analysis post training: On a validation set, 
    a. Get the difference between the image embeddings of correct and incorrectly classified samples to estimate the features present in the correctly classified samples but missing in the misclassified samples.
    b. Retrive the top 50 sentences from radiology report that matches closely to the embedding difference in step a.
    c. The sentence list is given below:
    {content}
    
    Task: 
    Ignore '___' as they are due to anonymization.
    Consider the consistent attributes present in the descriptions of correctly classified and misclassified samples regarding the positive Pneumothorax patients. Formulate hypotheses based on these attributes. Attributes are all the concepts (e.g, explicit or implicit anatomies, observations, demography related information or any concept leading to potential bias) in the sentences other than the class label (Pneumothorax in this case). Assess how these characteristics might be influencing the classifier's performance. Your response should contain only the list of top hypothesis, nothing else. For the response, you should be the following python dictionary template, no extra sentence:
    {hyp_dict}
    
    To effectively test Hypothesis 1 (H1) using the CLIP language encoder, you need to create prompts that explicitly validate H1. These prompts will help to generate text embeddings that capture the essence of the hypothesis, which can be used to compute similarity with the image embeddings from the dataset. The goal is to see if the images where the model makes mistakes are those that aligns with H1 or violates H1. The prompts are python list. Remember, your focus is only the class label "Pneumothorax" (i.e, positive Pneumothorax cases)
    
    Do this for all the hypothesis. Your final response should follow the following list of dictionaries, nothing else:
    
    {prompt_dict}
    
    Each attribute hypothesis should contain 5 prompts.
    
    So final response should follow the below format strictly (nothing else, no extra sentence): 
    ```python
        hypothesis_dict 
        prompt_dict 
    ```
    """

    return prompt


def create_RSNA_prompts(content):
    prompt_dict = """
    prompt_dict = 
    {
        H1_<attribute>: [List of prompts],
        H2_<attribute>: [List of prompts]
        ...
    }

    """

    hyp_dict = """
        hypothesis_dict = {
        "H1": "The classifier is making mistake  as it is biased toward <attribute>",
        "H2": "The classifier is making mistake as it is biased toward <attribute>",
        "H3": "The classifier is making mistake as it is biased toward <attribute>",
        ...
        }
    """

    prompt = f"""
    Context: Breast cancer classification from mammograms using a deep neural network
    Analysis post training: On a validation set, 
    a. Get the difference between the image embeddings of correct and incorrectly classified samples to estimate the features present in the correctly classified samples but missing in the misclassified samples.
    b. Retrive the top 50 sentences from radiology report that matches closely to the embedding difference in step a.
    c. The sentence list is given below:
    {content}
    
    Task: 
    Ignore '___' as they are due to anonymization.
    Consider the consistent attributes present in the descriptions of correctly classified and misclassified samples regarding the positive cancer patients. Formulate hypotheses based on these attributes. Attributes are all the concepts (e.g, explicit or implicit anatomies, observations, any symptom of change related to the disease, demography related information or any concept leading to potential bias) in the sentences other than the class label (Cancer in this case). Assess how these characteristics might be influencing the classifier's performance. Your response should contain only the list of top hypothesis, nothing else. For the response, you should be the following python dictionary template, no extra sentence:
    {hyp_dict}
    
    To effectively test Hypothesis 1 (H1) using the CLIP language encoder, you need to create prompts that explicitly validate H1. These prompts will help to generate text embeddings that capture the essence of the hypothesis, which can be used to compute similarity with the image embeddings from the dataset. The goal is to see if the images where the model makes mistakes are those that aligns with H1 or violates H1. The prompts are python list. Remember, your focus is only the class label "Cancer" (i.e, positive cancer cases)
    
    Do this for all the hypothesis. Your final response should follow the following list of dictionaries, nothing else:
    
    {prompt_dict}
    
    Each attribute hypothesis should contain 5 prompts.
    
    So final response should follow the below format strictly (nothing else, no extra sentence): 
    ```python
        hypothesis_dict 
        prompt_dict 
    ```
    """

    update_prompt = """
        Context: Breast cancer classification from mammograms using a deep neural network
            Analysis post training: On a validation set, 
            a. Get the difference between the image embeddings of correct and incorrectly classified samples to estimate the features present in the correctly classified samples but missing in the misclassified samples.
            b. Retrive the top 50 sentences from radiology report that matches closely to the embedding difference in step a.
            c. The sentence list is given below:
            1. a few scattered densities and tiny calcifications again seen bilaterally
        2. multiple densities and calcifications again seen bilaterally
        3. benign calcifications are identified along with bilateral asymmetries
        4. bilateral diffusely scattered punctate calcifications are again seen
        5. a few scattered densities and multiple scattered calcifications again seen bilaterally
        6. the left breast shows multiple scattered punctate calcifications that appear to have not significantly changed
        7. multiple scattered masses , densities , and calcifications again seen bilaterally
        8. multiple scattered densities and calcifications again seen bilaterally
        9. numerous scattered benign type calcifications can be identified in all 4 quadrants bilaterally
        10. the scattered densities and calcifications again seen
        11. no suspicious findings or significant changes are present as compared to the prior examination ( s ), the most recent dated [ date ] except for the calcifications are more visualized on the current study
        12. the left breast shows diffusely scattered punctate calcifications that appear to have not significantly changed
        13. multiple scattered masses and densities and a few scattered calcifications again seen bilaterally
        14. multiple scattered densities and a few calcifications again seen bilaterally
        15. a few scattered masses , densities , and calcifications again seen bilaterally
        16. scattered benign type calcifications can be identified bilaterally
        17. multiple scattered densities and a few calcifications are again seen bilaterally
        18. multiple bilateral scattered punctate calcifications are again seen
        19. numerous scattered punctate calcifications are seen again in both breasts
        20. multiple scattered calcifications and densities again seen in the right breast
        21. multiple scattered small masses , densities , and calcifications again seen bilaterally
        22. the scattered calcifications and densities again seen bilaterally
        23. multiple scattered calcifications and a few scattered densities are again seen bilaterally
        24. a few scattered densities and calcifications again seen bilaterally
        25. numerous scattered calcifications and a few densities again seen bilaterally
        26. several bilateral scattered punctate calcifications are seen in the upper outer quadrant quadrants of both breasts
        27. several bilateral scattered punctate calcifications seen are considered benign
        28. multiple scattered small densities and calcifications again seen
        29. multiple scattered calcifications and a few densities again seen bilaterally
        30. a few scattered small masses and densities and multiple scattered calcifications are again seen bilaterally
        31. multiple scattered calcifications and densities again seen bilaterally
        32. no suspicious findings or significant changes are present as compared to the prior examination ( s ), the most recent dated [ date ] and [ date ] [ address ] benign appearing calcifications are seen in both breasts
        33. [ address ] few scattered benign calcifications are seen in both breasts
        34. multiple scattered small densities and calcifications again seen bilaterally
        35. benign retroareolar calcifications can again be identified bilaterally
        36. multiple small masses and densities and a few scattered calcifications again seen bilaterally
        37. multiple scattered calcifications and a few scattered densities again seen bilaterally
        38. multiple scattered calcifications and a few density is again seen bilaterally
        39. multiple scattered calcifications and a few masses and densities again seen bilaterally
        40. multiple small scattered densities and calcifications again seen bilaterally
        41. scattered punctate calcifications are again noted bilaterally especially involving the left breast
        42. multiple scattered calcifications and a few scattered small densities are again seen bilaterally
        43. a few bilateral diffusely scattered calcified oil cysts are again seen
        44. stable benign appearing calcifications are seen in both breasts , to include vascular calcifications
        45. multiple scattered calcifications and a few scattered small densities again seen
        46. there are multiple scattered benign - appearing calcifications and a few scattered benign - appearing densities bilaterally
        47. slight scattered punctate benign calcifications are present bilaterally
        48. few benign calcifications are also seen bilaterally , without significant change
        49. a few scattered densities and calcifications again seen in both breasts
        50. stable benign appearing calcifications are seen in both breasts , to include vascular calcification
        
        In the previous conversation, you predicted the hypothesis which leads to the missclassifications.
        You also generated a set of prompts to test each hypothesis. These prompts are use to generate the sentence embedding
        and was used to compute the similarity with image embedding. The hypothesis and prompt dictionary is as follows:
        hypothesis_dict = {
            "H1": "The classifier is making mistakes due to the presence of scattered calcifications",
            "H2": "The classifier is making mistakes due to the appearance of multiple densities",
            "H3": "The classifier is making mistakes due to the description of masses",
            "H4": "The classifier is making mistakes due to references to bilateral occurrences",
            "H5": "The classifier is making mistakes due to the mention of changes over time"
        }
        
        prompt_dict = {
            "H1_scattered calcifications": [
                "Images showing scattered calcifications indicative of positive cancer cases",
                "Mammogram images with scattered calcifications typically linked to cancer",
                "Scattered calcifications in mammogram scans associated with cancer",
                "Mammograms depicting scattered calcifications, a sign of potential cancer",
                "Scans with scattered calcifications often corresponding to cancer diagnoses"
            ],
            "H2_multiple densities": [
                "Images displaying multiple densities, often seen in positive cancer cases",
                "Mammograms with multiple densities that may suggest the presence of cancer",
                "Multiple densities in mammograms linked to cancer",
                "Cancerous mammogram scans with multiple densities present",
                "Mammogram images showing multiple densities, possibly indicating cancer"
            ],
            "H3_masses": [
                "Images with masses that are commonly seen in cancerous breasts",
                "Mammogram scans showing masses, which could be cancerous",
                "Presence of masses in mammograms typically indicating cancer",
                "Mammograms depicting masses often associated with breast cancer",
                "Scans with visible masses that are suggestive of breast cancer"
            ],
            "H4_bilateral occurrences": [
                "Images showing bilateral occurrences in mammograms linked to cancer",
                "Mammogram images with bilateral signs often seen in cancer cases",
                "Bilateral abnormalities in mammograms indicating potential cancer",
                "Cancerous mammograms often display bilateral occurrences",
                "Mammogram scans with bilateral abnormalities suggesting cancer"
            ],
            "H5_changes over time": [
                "Images showing changes over time indicative of cancer progression",
                "Mammogram scans with visible changes over time linked to cancer development",
                "Changes in mammogram scans over time, a possible sign of cancer",
                "Mammograms with documented changes over time suggesting cancer",
                "Progressive changes in mammograms typically indicative of cancer"
            ]
        }
        
        The prompts and hypothesis were used to create the error slices for each hypothesis. Error slices are those
        clusters where the performance/accuracy of the model is lower than the performance/accuracy of the model 
        for the overall class. Ideally, the samples belonging to a slice not following the hypothesis should behave like this.
        Eg, H1_scattered calcifications where the performance (64.39%) of the model is
        significantly lower than the overall performance among cancer patients (76.5%). We aim to find such slices.
        
        The overeall accuracy of the model for detecting cancer in cancer patients is 76.5%. Refer to the following
        dictionary which follows the format as _slice_dict = {Hyp: accuracy},
        _slice_dict = {
            "H1_scattered calcifications": 64.39%,
            "H2_multiple densities": 71.21%,
            "H3_masses": 75.25%
            "H4_bilateral occurrences": 76.15%,
            "H5_changes over time": 87.87%
        }
        
        When analyzing error slices in machine learning models, particularly in medical imaging like breast cancer 
        classification from mammograms, focus on refining hypotheses for slices where the performance is very close to or 
        exceeds the overall model performance. This indicates that the current hypotheses might not adequately explain 
        the misclassifications, or the model handles those features well. 
        Update the hypotheses and associated prompts for these slices to better reflect observed error patterns and 
        improve the model's accuracy. Specifically, adjust the hypotheses where the error slice performance suggests 
        that the predicted factors may not be significant contributors to misclassifications or 
        are actually well-handled by the model.
        
        In the final response compute the updated hypothesis and the corresponding prompts to test the hypothesis.
        So final response should follow the below format strictly (nothing else, no extra sentence): 
            ```python
                hypothesis_dict 
                prompt_dict 
            ```
        """

    return prompt


def create_CELEBA_prompts(content):
    prompt_dict = """
    prompt_dict = 
    {
        H1_<attribute>: [List of prompts],
        H2_<attribute>: [List of prompts]
        ...
    }

    """

    hyp_dict = """
        hypothesis_dict = {
        "H1": "The classifier is making mistake  as it is biased toward <attribute>",
        "H2": "The classifier is making mistake as it is biased toward <attribute>",
        "H3": "The classifier is making mistake as it is biased toward <attribute>",
        ...
        }
    """

    prompt = f"""
    Context: Hair color (Blonde/Non blonde) classification from images of men and women using a deep neural network
    Analysis post training: On a validation set for the class label "Blonde", 
    a. Get the difference between the image embeddings of correct and incorrectly classified samples.
    b. Retrieve the top K sentences from the captions of the images that matches closely to the embedding difference in step a.
    c. The sentence list is given below in the descending order of similarity with the embedding difference:
    {content}
    
    These sentences represent the features present in the correctly classified samples but missing in the misclassified samples.
    Task: 
    The task is to reason why the model is making mistakes on the misclassified samples based on the sentences. To do so, consider the attributes present in the above captions regarding the samples with Blonde hair (i.e, the class label "Blonde"). Attributes are all the concepts (e.g, demography related concept etc) other than the class label. For example, key attributes to consider in the 1st sentence are woman, long hair, smiling, black top. So come up with the list of hypotheses based based on these attributes to reason why a model makes systematic mistakes. For the hypotheses, you should be the following python dictionary template, no extra sentence:
    {hyp_dict}
    You must follow the following rules to construct the hypotheses:
    1. You must pick specific attributes, e.g, white dress, not generic attributes like dress color.
    2. Your hypotheses must be based on the attributes present in the captions, nothing else.
    3. You must pay close attention to the attributes that are consistently present in the sentences. These attributes are likely to be the cause of the systematic mistakes on the misclassified samples.
    4. You must construct as many hypotheses possible.
    
    Next you have to test the hypothesis. To effectively test Hypothesis 1 (H1) using the CLIP language encoder, you need to create prompts that explicitly validate H1. These prompts will help to generate text embeddings that capture the essence of the hypothesis, which can be used to compute similarity with the image embeddings from the dataset. The goal is to see if the images for which the model makes mistakes are those that aligns with H1 or violates H1. The prompts are python list. Remember, your focus is only the class label "Blonde" (i.e, men/women with Blonde hair)
    
    Do this for all the hypothesis. Your final response should follow the following list of dictionaries, nothing else:
    
    {prompt_dict}
    
    Each attribute hypothesis should contain 5 prompts.
    
    So final response should follow the below format strictly (nothing else, no extra sentence): 
    ```python
        hypothesis_dict 
        prompt_dict 
    ```
    """

    return prompt


def create_Waterbirds_prompts(content):
    prompt_dict = """
    prompt_dict = 
    {
        H1_<attribute>: [List of prompts],
        H2_<attribute>: [List of prompts]
        ...
    }

    """

    hyp_dict = """
        hypothesis_dict = {
        "H1": "The classifier is making mistake  as it is biased toward <attribute>",
        "H2": "The classifier is making mistake as it is biased toward <attribute>",
        "H3": "The classifier is making mistake as it is biased toward <attribute>",
        ...
        }
    """

    prompt = f"""
    Context: Bird classification from images using a deep neural network
    Analysis post training: On a validation set, 
    a. Get the difference between the image embeddings of correct and incorrectly classified samples.
    b. Retrieve the top K sentences from the captions of the images that matches closely to the embedding difference in step a.
    c. The sentence list is given below in the descending order of similarity with the embedding difference:
    {content}
    
    These sentences represent the features present in the correctly classified samples but missing in the misclassified samples.
    Task: 
    The task is to reason why the model is making mistakes on the misclassified samples based on the sentences. To do so, consider the attributes present in the above captions regarding to the specific bird species. Attributes are all the concepts other than the class label. So come up with the list of hypotheses based based on these attributes to reason why a model makes systematic mistakes. For the hypotheses, you should be the following python dictionary template, no extra sentence:
    {hyp_dict}
    You must follow the following rules to construct the hypotheses:
    1. You must pick specific attributes, e.g, blue, not generic attributes like color.
    2. Your hypotheses must be based on the attributes present in the captions, nothing else.
    3. You must pay close attention to the attributes that are consistently present in the sentences. These attributes are likely to be the cause of the systematic mistakes on the misclassified samples.
    4. You must construct as many hypotheses possible.
    
    Next you have to test the hypothesis. To effectively test Hypothesis 1 (H1) using the CLIP language encoder, you need to create prompts that explicitly validate H1. These prompts will help to generate text embeddings that capture the essence of the hypothesis, which can be used to compute similarity with the image embeddings from the dataset. The goal is to see if the images for which the model makes mistakes are those that aligns with H1 or violates H1. The prompts are python list. Remember, your focus is only the specific bird.
    
    Do this for all the hypothesis. Your final response should follow the following list of dictionaries, nothing else:
    
    {prompt_dict}
    
    Each attribute hypothesis should contain 5 prompts.
    
    So final response should follow the below format strictly (nothing else, no extra sentence): 
    ```python
        hypothesis_dict 
        prompt_dict 
    ```
    """

    return prompt


def create_Metashift_prompts(content):
    prompt_dict = """
    prompt_dict = 
    {
        H1_<attribute>: [List of prompts],
        H2_<attribute>: [List of prompts]
        ...
    }

    """

    hyp_dict = """
        hypothesis_dict = {
        "H1": "The classifier is making mistake  as it is biased toward <attribute>",
        "H2": "The classifier is making mistake as it is biased toward <attribute>",
        "H3": "The classifier is making mistake as it is biased toward <attribute>",
        ...
        }
    """

    cat_prompt = f"""
    Context: Cat vs Dog classification from images using a deep neural network
    Analysis post training: On a validation set, 
    a. Get the difference between the image embeddings of correct and incorrectly classified samples.
    b. Retrieve the top K sentences from the captions of the images that matches closely to the embedding difference in step a.
    c. The sentence list is given below in the descending order of similarity with the embedding difference:
    {content}

    These sentences represent the features present in the correctly classified samples but missing in the misclassified samples.
    Task: 
    The task is to reason why the model is making mistakes on the misclassified samples based on the sentences for the class label 'cat'. To do so, consider the attributes present in the above captions regarding to the specific bird species. Attributes are all the concepts other than the class label (i.e, cat). So come up with the list of hypotheses based based on these attributes to reason why a model makes systematic mistakes. For the hypotheses, you should be the following python dictionary template, no extra sentence:
    {hyp_dict}
    You must follow the following rules to construct the hypotheses:
    1. You must pick specific attributes, e.g, blue, not generic attributes like color.
    2. Your hypotheses must be based on the attributes present in the captions, nothing else.
    3. You must pay close attention to the attributes that are consistently present in the sentences. These attributes are likely to be the cause of the systematic mistakes on the misclassified samples.
    4. You must construct as many hypotheses possible.

    Next you have to test the hypothesis. To effectively test Hypothesis 1 (H1) using the CLIP language encoder, you need to create prompts that explicitly validate H1. These prompts will help to generate text embeddings that capture the essence of the hypothesis, which can be used to compute similarity with the image embeddings from the dataset. The goal is to see if the images for which the model makes mistakes are those that aligns with H1 or violates H1. The prompts are python list. Remember, your focus is only the specific bird.

    Do this for all the hypothesis. Your final response should follow the following list of dictionaries, nothing else:

    {prompt_dict}

    Each attribute hypothesis should contain 5 prompts.

    So final response should follow the below format strictly (nothing else, no extra sentence): 
    ```python
        hypothesis_dict 
        prompt_dict 
    ```
    """

    dog_prompt = f"""
        Context: Cat vs Dog classification from images using a deep neural network
        Analysis post training: On a validation set, 
        a. Get the difference between the image embeddings of correct and incorrectly classified samples.
        b. Retrieve the top K sentences from the captions of the images that matches closely to the embedding difference in step a.
        c. The sentence list is given below in the descending order of similarity with the embedding difference:
        {content}

        These sentences represent the features present in the correctly classified samples but missing in the misclassified samples.
        Task: 
        The task is to reason why the model is making mistakes on the misclassified samples based on the sentences for the class label 'dog'. To do so, consider the attributes present in the above captions regarding to the specific bird species. Attributes are all the concepts other than the class label (i.e, dog). So come up with the list of hypotheses based based on these attributes to reason why a model makes systematic mistakes. For the hypotheses, you should be the following python dictionary template, no extra sentence:
        {hyp_dict}
        You must follow the following rules to construct the hypotheses:
        1. You must pick specific attributes, e.g, blue, not generic attributes like color.
        2. Your hypotheses must be based on the attributes present in the captions, nothing else.
        3. You must pay close attention to the attributes that are consistently present in the sentences. These attributes are likely to be the cause of the systematic mistakes on the misclassified samples.
        4. You must construct as many hypotheses possible.

        Next you have to test the hypothesis. To effectively test Hypothesis 1 (H1) using the CLIP language encoder, you need to create prompts that explicitly validate H1. These prompts will help to generate text embeddings that capture the essence of the hypothesis, which can be used to compute similarity with the image embeddings from the dataset. The goal is to see if the images for which the model makes mistakes are those that aligns with H1 or violates H1. The prompts are python list. Remember, your focus is only the specific bird.

        Do this for all the hypothesis. Your final response should follow the following list of dictionaries, nothing else:

        {prompt_dict}

        Each attribute hypothesis should contain 5 prompts.

        So final response should follow the below format strictly (nothing else, no extra sentence): 
        ```python
            hypothesis_dict 
            prompt_dict 
        ```
        """

    return cat_prompt, dog_prompt